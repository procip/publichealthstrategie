PHSAnhang Abkürzungen
+--------------------------------------+--------------------------------------+
| AA                                   | Auswärtiges Amt                      |
+--------------------------------------+--------------------------------------+
| ABAS                                 | Ausschuss für Biologische            |
|                                      | Arbeitsstoffe                        |
+--------------------------------------+--------------------------------------+
| AOLG                                 | Arbeitsgemeinschaft der Obersten     |
|                                      | Landesgesundheitsbehörden            |
+--------------------------------------+--------------------------------------+
| AOLG-AG GPRS                         | Arbeitsgemeinschaft der Obersten     |
|                                      | Landesgesundheitsbehörden - AG       |
|                                      | Gesundheitsberichterstattung,        |
|                                      | Prävention, Rehabilitation und       |
|                                      | Sozialmedizin                        |
+--------------------------------------+--------------------------------------+
| APS                                  | Aktionsbündnis Patientensicherheit   |
+--------------------------------------+--------------------------------------+
| ASPHER                               | Association of Schools of Public     |
|                                      | Health in the European Region        |
+--------------------------------------+--------------------------------------+
| BAuA                                 | Bundesanstalt für Arbeitsschutz und  |
|                                      | Arbeitsmedizin                       |
+--------------------------------------+--------------------------------------+
| BBK                                  | Bundesamt für Bevölkerungsschutz und |
|                                      | Katastrophenhilfe                    |
+--------------------------------------+--------------------------------------+
| BfArM                                | Bundesinstitut für Arzneimittel und  |
|                                      | Medizinprodukte                      |
+--------------------------------------+--------------------------------------+
| BfR                                  | Bundesinstitut für Risikobewertung   |
+--------------------------------------+--------------------------------------+
| BfS                                  | Bundesamt für Strahlenschutz         |
+--------------------------------------+--------------------------------------+
| BMAS                                 | Bundesministerium für Arbeit und     |
|                                      | Soziales                             |
+--------------------------------------+--------------------------------------+
| BMEL                                 | Bundesministerium für Ernährung und  |
|                                      | Landwirtschaft                       |
+--------------------------------------+--------------------------------------+
| BMFSFJ                               | Bundesministerium für Familie,       |
|                                      | Senioren, Frauen und Jugend          |
+--------------------------------------+--------------------------------------+
| BMG                                  | Bundesministerium für Gesundheit     |
+--------------------------------------+--------------------------------------+
| BMI                                  | Bundesministerium des Innern, für    |
|                                      | Bau und Heimat                       |
+--------------------------------------+--------------------------------------+
| BMJV                                 | Bundesministerium der Justiz und für |
|                                      | Verbraucherschutz                    |
+--------------------------------------+--------------------------------------+
| BMUB                                 | Bundesministerium für Umwelt,        |
|                                      | Naturschutz und nukleare Sicherheit  |
+--------------------------------------+--------------------------------------+
| BMVI                                 | Bundesministerium für Verkehr und    |
|                                      | digitale Infrastruktur               |
+--------------------------------------+--------------------------------------+
| BVL                                  | Bundesamt für Verbraucherschutz und  |
|                                      | Lebensmittelsicherheit               |
+--------------------------------------+--------------------------------------+
| Bvmd                                 | Bundesvertretung der                 |
|                                      | Medizinstudierenden                  |
+--------------------------------------+--------------------------------------+
| BZgA                                 | Bundeszentrale für gesundheitliche   |
|                                      | Aufklärung                           |
+--------------------------------------+--------------------------------------+
| DEGS                                 | Studie zur Gesundheit Erwachsener in |
|                                      | Deutschland                          |
+--------------------------------------+--------------------------------------+
| DESTATIS                             | Statistisches Bundesamt              |
+--------------------------------------+--------------------------------------+
| DFG                                  | Deutsche Forschungsgemeinschaft      |
+--------------------------------------+--------------------------------------+
| DGEpi                                | Deutsche Gesellschaft für            |
|                                      | Epidemiologie                        |
+--------------------------------------+--------------------------------------+
| DGMS                                 | Deutsche Gesellschaft für            |
|                                      | Medizinische Soziologie              |
+--------------------------------------+--------------------------------------+
| DGPH                                 | Deutsche Gesellschaft Public Health  |
+--------------------------------------+--------------------------------------+
| DGSMP                                | Deutsche Gesellschaft für            |
|                                      | Sozialmedizin und Prävention         |
+--------------------------------------+--------------------------------------+
| DKG                                  | Deutsche Krankenhausgesellschaft     |
+--------------------------------------+--------------------------------------+
| DVG                                  | Digitale-Versorgung-Gesetz           |
+--------------------------------------+--------------------------------------+
| ECDC                                 | European Centre for Disease          |
|                                      | Prevention and Control               |
+--------------------------------------+--------------------------------------+
| EPHO                                 | Essential Public Health Operations   |
+--------------------------------------+--------------------------------------+
| EU                                   | Europäische Union                    |
+--------------------------------------+--------------------------------------+
| FLI                                  | Friedrich-Loeffler-Institut          |
+--------------------------------------+--------------------------------------+
| GBA                                  | Gemeinsamer Bundesausschuss          |
+--------------------------------------+--------------------------------------+
| GBE                                  | Gesundheitsberichterstattung         |
+--------------------------------------+--------------------------------------+
| GEDA                                 | Gesundheit in Deutschland aktuell    |
+--------------------------------------+--------------------------------------+
| GG                                   | Grundgesetz                          |
+--------------------------------------+--------------------------------------+
| GIS                                  | Geographische Informationssysteme    |
+--------------------------------------+--------------------------------------+
| GKV                                  | Gesetzliche Krankenversicherung      |
+--------------------------------------+--------------------------------------+
| GMDS                                 | Deutsche Gesellschaft für            |
|                                      | Medizinische Informatik, Biometrie   |
|                                      | und Epidemiologie                    |
+--------------------------------------+--------------------------------------+
| GMK                                  | Gesundheitsministerkonferenz         |
+--------------------------------------+--------------------------------------+
| HACCP                                | Hazard Analysis and Critical Control |
|                                      | Points-Konzept                       |
+--------------------------------------+--------------------------------------+
| HiAP                                 | Health in All Policies               |
+--------------------------------------+--------------------------------------+
| HIS                                  | Health-Information-System            |
+--------------------------------------+--------------------------------------+
| IfSG                                 | Infektionsschutzgesetz               |
+--------------------------------------+--------------------------------------+
| IGV                                  | Internationalen                      |
|                                      | Gesundheitsvorschriften              |
+--------------------------------------+--------------------------------------+
| INEK                                 | Institut für das Entgeltsystem im    |
|                                      | Krankenhaus                          |
+--------------------------------------+--------------------------------------+
| IQTiG                                | Institut für Qualität und            |
|                                      | Transparenz im Gesundheitswesen      |
+--------------------------------------+--------------------------------------+
| IQWiG                                | Institut für Qualität und            |
|                                      | Wirtschaftlichkeit im                |
|                                      | Gesundheitswese                      |
+--------------------------------------+--------------------------------------+
| KBV                                  | Kassenärztliche Bundesvereinigung    |
+--------------------------------------+--------------------------------------+
| KiGGS                                | Studie zur Gesundheit von Kindern    |
|                                      | und Jugendlichen in Deutschland      |
+--------------------------------------+--------------------------------------+
| LÜKEX-Übungen                        | Länder-übergreifenden Krisen         |
|                                      | Exercise                             |
+--------------------------------------+--------------------------------------+
| MRI                                  | Max-Rubner-Institut                  |
+--------------------------------------+--------------------------------------+
| NCD                                  | Non communicable diseases,           |
|                                      | nichtübertragbare Erkrankungen       |
+--------------------------------------+--------------------------------------+
| NGO                                  | Nichtregierungsorganisation          |
+--------------------------------------+--------------------------------------+
| NÖG                                  | Nachwuchsnetzwerk Öffentliche        |
|                                      | Gesundheit                           |
+--------------------------------------+--------------------------------------+
| OECD                                 | Organisation für wirtschaftliche     |
|                                      | Zusammenarbeit und Entwicklung       |
+--------------------------------------+--------------------------------------+
| ÖGD                                  | Öffentlicher Gesundheitsdienst       |
+--------------------------------------+--------------------------------------+
| ÖPNV                                 | Öffentlicher Personennahverkehr      |
+--------------------------------------+--------------------------------------+
| PEI                                  | Paul-Ehrlich-Institut                |
+--------------------------------------+--------------------------------------+
| PH                                   | Public Health                        |
+--------------------------------------+--------------------------------------+
| PKV                                  | Private Krankenversicherung          |
+--------------------------------------+--------------------------------------+
| RCCE                                 | Risk communication and community     |
|                                      | engagement                           |
+--------------------------------------+--------------------------------------+
| RKI                                  |  Robert Koch-Institut                |
+--------------------------------------+--------------------------------------+
| SROI                                 | Social Return in Investment          |
+--------------------------------------+--------------------------------------+
| UBA                                  | Umweltbundesamt                      |
+--------------------------------------+--------------------------------------+
| THW                                  | Technisches Hilfswerk                |
+--------------------------------------+--------------------------------------+
| WHO                                  | Weltgesundheitsorganisation          |
+--------------------------------------+--------------------------------------+
| ZfPH                                 | Zukunftsforum Public Health          |
+--------------------------------------+--------------------------------------+


