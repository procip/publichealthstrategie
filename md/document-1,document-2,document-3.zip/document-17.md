PHSAnhang Abkürzungen
<table>
<col width="50%" />
<col width="50%" />
<tbody>
<tr class="odd">
<td align="left"><p>AA</p></td>
<td align="left"><p>Auswärtiges Amt</p></td>
</tr>
<tr class="even">
<td align="left"><p>ABAS</p></td>
<td align="left"><p>Ausschuss für Biologische Arbeitsstoffe</p></td>
</tr>
<tr class="odd">
<td align="left"><p>AOLG</p></td>
<td align="left"><p>Arbeitsgemeinschaft der Obersten Landesgesundheitsbehörden</p></td>
</tr>
<tr class="even">
<td align="left"><p>AOLG-AG GPRS</p></td>
<td align="left"><p>Arbeitsgemeinschaft der Obersten Landesgesundheitsbehörden - AG Gesundheitsberichterstattung, Prävention, Rehabilitation und Sozialmedizin</p></td>
</tr>
<tr class="odd">
<td align="left"><p>APS</p></td>
<td align="left"><p>Aktionsbündnis Patientensicherheit</p></td>
</tr>
<tr class="even">
<td align="left"><p>ASPHER</p></td>
<td align="left"><p>Association of Schools of Public Health in the European Region</p></td>
</tr>
<tr class="odd">
<td align="left"><p>BAuA</p></td>
<td align="left"><p>Bundesanstalt für Arbeitsschutz und Arbeitsmedizin</p></td>
</tr>
<tr class="even">
<td align="left"><p>BBK</p></td>
<td align="left"><p>Bundesamt für Bevölkerungsschutz und Katastrophenhilfe</p></td>
</tr>
<tr class="odd">
<td align="left"><p>BfArM</p></td>
<td align="left"><p>Bundesinstitut für Arzneimittel und Medizinprodukte</p></td>
</tr>
<tr class="even">
<td align="left"><p>BfR</p></td>
<td align="left"><p>Bundesinstitut für Risikobewertung</p></td>
</tr>
<tr class="odd">
<td align="left"><p>BfS</p></td>
<td align="left"><p>Bundesamt für Strahlenschutz</p></td>
</tr>
<tr class="even">
<td align="left"><p>BMAS</p></td>
<td align="left"><p>Bundesministerium für Arbeit und Soziales</p></td>
</tr>
<tr class="odd">
<td align="left"><p>BMEL</p></td>
<td align="left"><p>Bundesministerium für Ernährung und Landwirtschaft</p></td>
</tr>
<tr class="even">
<td align="left"><p>BMFSFJ</p></td>
<td align="left"><p>Bundesministerium für Familie, Senioren, Frauen und Jugend</p></td>
</tr>
<tr class="odd">
<td align="left"><p>BMG</p></td>
<td align="left"><p>Bundesministerium für Gesundheit</p></td>
</tr>
<tr class="even">
<td align="left"><p>BMI</p></td>
<td align="left"><p>Bundesministerium des Innern, für Bau und Heimat</p></td>
</tr>
<tr class="odd">
<td align="left"><p>BMJV</p></td>
<td align="left"><p>Bundesministerium der Justiz und für Verbraucherschutz</p></td>
</tr>
<tr class="even">
<td align="left"><p>BMUB</p></td>
<td align="left"><p>Bundesministerium für Umwelt, Naturschutz und nukleare Sicherheit</p></td>
</tr>
<tr class="odd">
<td align="left"><p>BMVI</p></td>
<td align="left"><p>Bundesministerium für Verkehr und digitale Infrastruktur</p></td>
</tr>
<tr class="even">
<td align="left"><p>BVL</p></td>
<td align="left"><p>Bundesamt für Verbraucherschutz und Lebensmittelsicherheit</p></td>
</tr>
<tr class="odd">
<td align="left"><p>Bvmd</p></td>
<td align="left"><p>Bundesvertretung der Medizinstudierenden</p></td>
</tr>
<tr class="even">
<td align="left"><p>BZgA</p></td>
<td align="left"><p>Bundeszentrale für gesundheitliche Aufklärung</p></td>
</tr>
<tr class="odd">
<td align="left"><p>DEGS</p></td>
<td align="left"><p>Studie zur Gesundheit Erwachsener in Deutschland</p></td>
</tr>
<tr class="even">
<td align="left"><p>DESTATIS</p></td>
<td align="left"><p>Statistisches Bundesamt</p></td>
</tr>
<tr class="odd">
<td align="left"><p>DFG</p></td>
<td align="left"><p>Deutsche Forschungsgemeinschaft</p></td>
</tr>
<tr class="even">
<td align="left"><p>DGEpi</p></td>
<td align="left"><p>Deutsche Gesellschaft für Epidemiologie</p></td>
</tr>
<tr class="odd">
<td align="left"><p>DGMS</p></td>
<td align="left"><p>Deutsche Gesellschaft für Medizinische Soziologie</p></td>
</tr>
<tr class="even">
<td align="left"><p>DGPH</p></td>
<td align="left"><p>Deutsche Gesellschaft Public Health</p></td>
</tr>
<tr class="odd">
<td align="left"><p>DGSMP</p></td>
<td align="left"><p>Deutsche Gesellschaft für Sozialmedizin und Prävention</p></td>
</tr>
<tr class="even">
<td align="left"><p>DKG</p></td>
<td align="left"><p>Deutsche Krankenhausgesellschaft</p></td>
</tr>
<tr class="odd">
<td align="left"><p>DVG</p></td>
<td align="left"><p>Digitale-Versorgung-Gesetz</p></td>
</tr>
<tr class="even">
<td align="left"><p>ECDC</p></td>
<td align="left"><p>European Centre for Disease Prevention and Control</p></td>
</tr>
<tr class="odd">
<td align="left"><p>EPHO</p></td>
<td align="left"><p>Essential Public Health Operations</p></td>
</tr>
<tr class="even">
<td align="left"><p>EU</p></td>
<td align="left"><p>Europäische Union</p></td>
</tr>
<tr class="odd">
<td align="left"><p>FLI</p></td>
<td align="left"><p>Friedrich-Loeffler-Institut</p></td>
</tr>
<tr class="even">
<td align="left"><p>GBA</p></td>
<td align="left"><p>Gemeinsamer Bundesausschuss</p></td>
</tr>
<tr class="odd">
<td align="left"><p>GBE</p></td>
<td align="left"><p>Gesundheitsberichterstattung</p></td>
</tr>
<tr class="even">
<td align="left"><p>GEDA</p></td>
<td align="left"><p>Gesundheit in Deutschland aktuell</p></td>
</tr>
<tr class="odd">
<td align="left"><p>GG</p></td>
<td align="left"><p>Grundgesetz</p></td>
</tr>
<tr class="even">
<td align="left"><p>GIS</p></td>
<td align="left"><p>Geographische Informationssysteme</p></td>
</tr>
<tr class="odd">
<td align="left"><p>GKV</p></td>
<td align="left"><p>Gesetzliche Krankenversicherung</p></td>
</tr>
<tr class="even">
<td align="left"><p>GMDS</p></td>
<td align="left"><p>Deutsche Gesellschaft für Medizinische Informatik, Biometrie und Epidemiologie</p></td>
</tr>
<tr class="odd">
<td align="left"><p>GMK</p></td>
<td align="left"><p>Gesundheitsministerkonferenz</p></td>
</tr>
<tr class="even">
<td align="left"><p>HACCP</p></td>
<td align="left"><p>Hazard Analysis and Critical Control Points-Konzept</p></td>
</tr>
<tr class="odd">
<td align="left"><p>HiAP</p></td>
<td align="left"><p>Health in All Policies</p></td>
</tr>
<tr class="even">
<td align="left"><p>HIS</p></td>
<td align="left"><p>Health-Information-System</p></td>
</tr>
<tr class="odd">
<td align="left"><p>IfSG</p></td>
<td align="left"><p>Infektionsschutzgesetz</p></td>
</tr>
<tr class="even">
<td align="left"><p>IGV</p></td>
<td align="left"><p>Internationalen Gesundheitsvorschriften</p></td>
</tr>
<tr class="odd">
<td align="left"><p>INEK</p></td>
<td align="left"><p>Institut für das Entgeltsystem im Krankenhaus</p></td>
</tr>
<tr class="even">
<td align="left"><p>IQTiG</p></td>
<td align="left"><p>Institut für Qualität und Transparenz im Gesundheitswesen</p></td>
</tr>
<tr class="odd">
<td align="left"><p>IQWiG </p></td>
<td align="left"><p>Institut für Qualität und Wirtschaftlichkeit im Gesundheitswese</p></td>
</tr>
<tr class="even">
<td align="left"><p>KBV</p></td>
<td align="left"><p>Kassenärztliche Bundesvereinigung</p></td>
</tr>
<tr class="odd">
<td align="left"><p>KiGGS</p></td>
<td align="left"><p>Studie zur Gesundheit von Kindern und Jugendlichen in Deutschland</p></td>
</tr>
<tr class="even">
<td align="left"><p>LÜKEX-Übungen</p></td>
<td align="left"><p>Länder-übergreifenden Krisen Exercise</p></td>
</tr>
<tr class="odd">
<td align="left"><p>MRI</p></td>
<td align="left"><p>Max-Rubner-Institut</p></td>
</tr>
<tr class="even">
<td align="left"><p>NCD</p></td>
<td align="left"><p>Non communicable diseases, nichtübertragbare Erkrankungen</p></td>
</tr>
<tr class="odd">
<td align="left"><p>NGO</p></td>
<td align="left"><p>Nichtregierungsorganisation</p></td>
</tr>
<tr class="even">
<td align="left"><p>NÖG</p></td>
<td align="left"><p>Nachwuchsnetzwerk Öffentliche Gesundheit</p></td>
</tr>
<tr class="odd">
<td align="left"><p>OECD</p></td>
<td align="left"><p>Organisation für wirtschaftliche Zusammenarbeit und Entwicklung</p></td>
</tr>
<tr class="even">
<td align="left"><p>ÖGD</p></td>
<td align="left"><p>Öffentlicher Gesundheitsdienst</p></td>
</tr>
<tr class="odd">
<td align="left"><p>ÖPNV</p></td>
<td align="left"><p>Öffentlicher Personennahverkehr</p></td>
</tr>
<tr class="even">
<td align="left"><p>PEI</p></td>
<td align="left"><p>Paul-Ehrlich-Institut</p></td>
</tr>
<tr class="odd">
<td align="left"><p>PH</p></td>
<td align="left"><p>Public Health</p></td>
</tr>
<tr class="even">
<td align="left"><p>PKV</p></td>
<td align="left"><p>Private Krankenversicherung</p></td>
</tr>
<tr class="odd">
<td align="left"><p>RCCE</p></td>
<td align="left"><p>Risk communication and community engagement</p></td>
</tr>
<tr class="even">
<td align="left"><p>RKI</p></td>
<td align="left"><p> Robert Koch-Institut</p></td>
</tr>
<tr class="odd">
<td align="left"><p>SROI</p></td>
<td align="left"><p>Social Return in Investment</p></td>
</tr>
<tr class="even">
<td align="left"><p>UBA</p></td>
<td align="left"><p>Umweltbundesamt</p></td>
</tr>
<tr class="odd">
<td align="left"><p>THW</p></td>
<td align="left"><p>Technisches Hilfswerk</p></td>
</tr>
<tr class="even">
<td align="left"><p>WHO</p></td>
<td align="left"><p>Weltgesundheitsorganisation</p></td>
</tr>
<tr class="odd">
<td align="left"><p>ZfPH</p></td>
<td align="left"><p>Zukunftsforum Public Health</p></td>
</tr>
</tbody>
</table>


