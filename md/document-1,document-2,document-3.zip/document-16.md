PHS Impressum

Redaktionsgruppe: Karin Geffert, Ansgar Gerhardus, Joseph Kuhn, Julika
Loss, Peter von Philipsborn, Hajo Zeeb

Autor:innen: EPHO 1: Laura Arnold, Joseph Kuhn, Thomas Ziese; EPHO 2:
Ute Rexroth; EPHO 3: Joseph Kuhn, Wolfgang Hoffmann, EPHO 4: Freia De
Bock, Petra Kolip, Peter von Philipsborn, Stefan Pospiech, Ute Thyen;
EPHO 5: Freia De Bock, Petra Kolip, Peter von Philipsborn, Stefan
Pospiech, Ute Thyen; EPHO 6: Raimund Geene, Manfred Wildner; EPHO 7:
Karin Geffert, Bertram Geisel, Peter Tinnemann; EPHO 8: Raimund Geene,
Katharina Mörschel, Manfred Wildner; EPHO 9: Julika Loss; EPHO 10: Nico
Dragano, Ansgar Gerhardus, Hajo Zeeb

Online-Konsultation: Claudia Böhm, Karin Geffert, Sophie Gepp, Svenja
Matusall, Susanne Moebus, Kerstin Sell, Peter Tinnemann

Schlussredaktion: Karin Geffert, Svenja Matusall, Susanne Moebus, Judith
Schröder

Layout: Jörg Schaarschmidt

Wir möchten den zahlreichen Reviewer:innen, den Teilnehmenden unserer
Symposien sowie allen Kolleg:innen der Public-Health-Gemeinschaft, die
sich an den beiden Online-Konsultationsrunden beteiligt haben, für
Diskussionen, Anregungen und Kommentare danken. Darüber hinaus gilt
unser Dank dem Robert Koch-Institut für die Bereitstellung der
Geschäftsstelle des Zukunftsforums, dem Bundesministerium für
Gesundheit, dem Robert Koch-Institut, der Bundeszentrale für
Gesundheitliche Aufklärung sowie dem Leibniz-Institut für
Präventionsforschung und Epidemiologie – BIPS für die finanzielle
Förderung der verschiedenen Symposien des Zukunftsforums, der
Steuerungsgruppe des Zukunftsforums, sowie dem Nachwuchsnetzwerk
Öffentliche Gesundheit, deren Vertreter:innen maßgeblich inhaltlich,
sowie operationell zu dem Prozess beigetragen haben.

 
